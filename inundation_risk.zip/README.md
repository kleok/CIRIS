# Inundation Risk Tool 🌊🏛️

This tool generates inundation risk layers for coastal cultural heritage areas using remote sensing data.

## Features
- DEM clipping and masking
- Sea level rise interpolation (IDW)
- Risk percentage generation
- Output in GeoTIFF and NetCDF

## Structure
- `inundation_risk/`: Core logic (data loading, processing, analysis)
- `notebooks/`: User-facing notebook for execution
- `tests/`: Sample test scaffolding

## Usage
```bash
pip install -r requirements.txt
jupyter notebook notebooks/generate_inundation_risk.ipynb
```

